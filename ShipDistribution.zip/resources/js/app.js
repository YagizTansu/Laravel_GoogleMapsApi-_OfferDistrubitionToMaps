require('./bootstrap');

import Alpine from 'alpinejs';
window.Alpine = Alpine;
Alpine.start();

require('jquery');

import $ from 'jquery';
window.jQuery = $;
window.$ = $
