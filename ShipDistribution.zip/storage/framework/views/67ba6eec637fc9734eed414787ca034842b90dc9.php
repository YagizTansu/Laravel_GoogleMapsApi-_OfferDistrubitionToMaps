<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> Ships <?php $__env->endSlot(); ?>

    <div class="card">
        <div class="card-body">

            <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                    <strong><?php echo e(session('success')); ?></strong>
                </div>
            <?php endif; ?>


            <a href="<?php echo e(route('ships.create')); ?>" class="btn btn-primary mb-2">Create new Ships location </a>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">name</th>
                        <th scope="col">latitude</th>
                        <th scope="col">longitude</th>
                        <th scope="col">radius</th>
                        <th scope="col">operation</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $ships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($ship->name); ?></td>
                            <td><?php echo e($ship->latitude); ?></td>
                            <td><?php echo e($ship->longitude); ?></td>
                            <td><?php echo e($ship->radius); ?></td>
                            <td>
                                <a href="<?php echo e(route('ships.edit', $ship->id)); ?>" class="btn btn-primary">edit</a>
                                <a href="<?php echo e(route('ships.destroy', $ship->id)); ?>" class="btn btn-danger">delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>

     <?php $__env->slot('js'); ?>  <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\yagiz\Desktop\ShipDistribution\resources\views/Admin/Ships/ships.blade.php ENDPATH**/ ?>